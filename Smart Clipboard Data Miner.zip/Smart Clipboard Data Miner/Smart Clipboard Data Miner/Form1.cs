﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Smart_Clipboard_Data_Miner
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnGetTextAction(object sender, EventArgs e)
        {
            if (Clipboard.ContainsText())
            {
                Clipboard.GetText();
                MessageBox.Show("Clipboard text waiting for pasting");
            }
            else
            {
                MessageBox.Show("Your Clipboard Does not containt Text data Formats");
            }
            
            
        }

        private void btnGetImageAction(object sender, EventArgs e)
        {
            if (Clipboard.ContainsImage())
            {
                Clipboard.GetImage();
                MessageBox.Show("Clipboard Images waiting for pasting");
            }
            else
            {
                MessageBox.Show("No Image Data Found on the Clipboard");
            }
        }

        private void btnGetHtmlAction(object sender, EventArgs e)
        {
            if (Clipboard.ContainsData(DataFormats.Html))
            {
                Clipboard.GetData(DataFormats.Html);
                MessageBox.Show("Clipboard Html waiting for pasting");
            }
            
            
        }

        private void btnGetAlFormatsAction(object sender, EventArgs e)
        {
            if (Clipboard.ContainsFileDropList())
            {
                Clipboard.GetFileDropList();
                MessageBox.Show("Clipboard files waiting for pasting");
            }
            else
            {
                MessageBox.Show("ClipBoard Is Empty");
            }
            

        }

        private void btnClearClipboardAction(object sender, EventArgs e)
        {
            Clipboard.Clear();
            MessageBox.Show("Clipboard has been cleared");
        }

        private void btnPasteAction(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            if (ofd.ShowDialog() == DialogResult.OK && fbd.ShowDialog() == DialogResult.OK)
            {
                /**
                String mypath = fbd.SelectedPath;
                String selectedP = ofd.FileName;

                File.Copy(selectedP,mypath);
                **/
            }
        }
    }
}
