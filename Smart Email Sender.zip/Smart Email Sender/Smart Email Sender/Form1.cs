﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smart_Email_Sender
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLoginClick(object sender, EventArgs e)
        {
            this.Hide();
            Form2 windowApplication = new Form2();
            windowApplication.Show();
        }

        private void btnClearClick(object sender, EventArgs e)
        {
            textBox1.Text = "";
            maskedTextBox1.Text = "";
        }

        private void btnExitClick(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
