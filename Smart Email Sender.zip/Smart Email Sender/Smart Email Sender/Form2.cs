﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GmailSend;

namespace Smart_Email_Sender
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnAttachClick(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "All IMAGES|*.jpg|*.gif|*.png)";
            if (ofd.ShowDialog() == DialogResult.OK) {
                pictureBox2.ImageLocation = ofd.FileName;
                textBox6.Text = ofd.SafeFileName;
            }
        }

        private void btnClearClick(object sender, EventArgs e)
        {
            clearFields();
        }
        public void clearFields() {
           
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
        }

        private void btnSendEmailClick(object sender, EventArgs e)
        {
            try
            {
                gmail mail = new gmail();
                mail.auth(textBox1.Text, textBox2.Text);
                mail.To = textBox3.Text;
                mail.Subject = textBox4.Text;
                mail.Message = textBox5.Text;


                mail.Priority = 1;
                mail.send();
                MessageBox.Show("Sending EMAIL... Please Wait");
            }
            catch (Exception ex) {
                MessageBox.Show("Error sending Email: Check your Input and Retry");
            }
            
        }

        private void btnBackClick(object sender, EventArgs e)
        {
            Form1 goBack = new Form1();
            this.Hide();
            goBack.Show();
            
            
        }
    }
}
