﻿Imports System.IO
Imports System.Drawing.Printing

Public Class Form1
    Private strFileName As String
    Private objStreamToPrint As StreamReader
    Private objPrintFont As Font

    Private Sub btnPrintAction(sender As Object, e As EventArgs) Handles Button1.Click
        'Declare an object for the printDocument class
        Dim objPrintDocument As PrintDocument = New PrintDocument

        'Set The document name property
        objPrintDocument.DocumentName = "Text File print Name"

        'setting the printdialog properties
        PrintDialog1.AllowPrintToFile = False
        PrintDialog1.AllowSelection = False
        PrintDialog1.AllowSomePages = False

        'Set the document property to the objprintdocument object
        PrintDialog1.Document = objPrintDocument

        'Show the print dilaog
        If PrintDialog1.ShowDialog = DialogResult.OK Then
            objStreamToPrint = New StreamReader(strFileName)

            'set The print font
            objPrintFont = New Font("Arial", 10)

            'Add an event handler for the print page event of the objPrintDocument object
            AddHandler objPrintDocument.PrintPage, AddressOf objPrintDocument_PrintPage

            objPrintDocument.PrinterSettings = PrintDialog1.PrinterSettings


            'Print the text file
            objPrintDocument.Print()

            'Clean up
            objStreamToPrint.Close()
            objStreamToPrint = Nothing

        End If
    End Sub

    Private Sub objPrintDocument_PrintPage(sender As Object, e As PrintPageEventArgs)
        'Declare the variables
        Dim angLinePerPage As Single = 0
        Dim angVerticalPosition As Single = 0
        Dim intLineCount As Integer = 0
        Dim angLeftMargin As Single = e.MarginBounds.Left
        Dim angTopMargin As Single = e.MarginBounds.Top
        Dim strLine As String

        angLinePerPage = e.MarginBounds.Height / objPrintFont.GetHeight(e.Graphics)
        strLine = objStreamToPrint.ReadLine()

        While (intLineCount = angLinePerPage And Not (strLine Is Nothing))
            angVerticalPosition = angTopMargin + (intLineCount * objPrintFont.GetHeight(e.Graphics))
            e.Graphics.DrawString(strLine, objPrintFont, Brushes.Black,
            angLeftMargin, angVerticalPosition, New StringFormat())

            'increment the line count
            intLineCount = intLineCount + 1

            If (intLineCount < angLinePerPage) Then
                strLine = objStreamToPrint.ReadLine

            End If

        End While

        If (strLine <> Nothing) Then
            e.HasMorePages = True
        Else
            e.HasMorePages = False
        End If

        Throw New NotImplementedException()
    End Sub
End Class
